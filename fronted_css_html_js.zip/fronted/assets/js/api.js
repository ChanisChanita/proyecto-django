async function fetchProducts() {
    const response = await fetch("http://127.0.0.1:8000/api/products");
    const products = await response.json();
    const tableBody = document.getElementById("products-table");
    tableBody.innerHTML = "";
    products.forEach(product => {
        const row = `<tr>
            <td>${product.id}</td>
            <td>${product.name}</td>
            <td>${product.price}</td>
            <td>${product.stock}</td>
            <td>${product.description}</td>
            <td>
                <button class="btn btn-warning" onclick="editProduct(${product.id}, '${product.name}', ${product.price},${product.stock},'${product.description}')" data-bs-toggle="modal" data-bs-target="#editProductModal">Editar</button>
                <button class="btn btn-danger" onclick="deleteProduct(${product.id})" data-bs-toggle="modal" data-bs-target="#deleteConfirmModal">Eliminar</button>
            </td>
        </tr>`;
        tableBody.innerHTML += row;
    });
}

async function addProduct() {
    const name = document.getElementById("name").value;
    const description = document.getElementById("description").value;
    const price = document.getElementById("price").value;
    const stock = document.getElementById("stock").value;

    if (!name || !description || !price || !stock) {
        alert("Please enter all required fields: Name, Description, Price, and Stock.");
        return;
    }

    const productData = {
        name: name,
        description: description,
        price: parseFloat(price),
        stock: parseInt(stock)
    };

    try {
        const response = await fetch("http://127.0.0.1:8000/api/products/new", { 
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(productData)
        });

        if (!response.ok) {
            const errorData = await response.json(); 
            throw new Error(errorData.detail || `HTTP Error: ${response.status}`);
        }

        const data = await response.json();
        fetchProducts(); 

        document.getElementById("name").value = "";
        document.getElementById("description").value = "";
        document.getElementById("price").value = "";
        document.getElementById("stock").value = "";

        const modalElement = document.getElementById("addProductModal");
        const modalInstance = bootstrap.Modal.getInstance(modalElement);
        if (modalInstance) {
            modalInstance.hide();
        }

        alert("Product added successfully!");

    } catch (error) {
        alert("Error adding product. Check console for details.");
    }
}



function editProduct(id, name, price,stock,description) {
    document.getElementById("editId").value = id;
    document.getElementById("editName").value = name;
    document.getElementById("editPrice").value = price;
    document.getElementById("editStock").value = stock;
    document.getElementById("editDescription").value = description;
}

async function saveEdit() {
    const id = document.getElementById("editId").value;
    const name = document.getElementById("editName").value;
    const description = document.getElementById("editDescription").value;
    const price = document.getElementById("editPrice").value;
    const stock = document.getElementById("editStock").value;

    if (!id || !name || !description || !price || !stock) {
        alert("Please fill in all fields: Name, Description, Price, and Stock.");
        return;
    }

    const productData = {
        name: name,
        description: description,
        price: parseFloat(price),
        stock: parseInt(stock)
    };

    try {
        const response = await fetch(`http://127.0.0.1:8000/api/products/update/${id}`, { 
            method: "PUT",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(productData)
        });

        if (!response.ok) {
            const errorData = await response.json(); 
            throw new Error(errorData.detail || `HTTP Error: ${response.status}`);
        }

        const data = await response.json();
        fetchProducts(); 

        const modalElement = document.getElementById("editProductModal");
        const modalInstance = bootstrap.Modal.getInstance(modalElement);
        if (modalInstance) {
            modalInstance.hide();
        }

        alert("Product updated successfully!");

    } catch (error) {
        alert("Error updating product. Check console for details.");
    }
}


function deleteProduct(id) {
    document.getElementById("deleteId").value = id;
}

async function confirmDelete() {
    const id = document.getElementById("deleteId").value;

    if (!id) {
        alert("Invalid product ID.");
        return;
    }

    try {
        const response = await fetch(`http://127.0.0.1:8000/api/products/delete/${id}`, {
            method: "DELETE",
            headers: {
                "Content-Type": "application/json"
            }
        });

        if (!response.ok) {
            const errorData = await response.json();
            throw new Error(errorData.detail || `HTTP Error: ${response.status}`);
        }

        alert("Product deleted successfully!");
        fetchProducts();

        const modalElement = document.getElementById("deleteConfirmModal");
        const modalInstance = bootstrap.Modal.getInstance(modalElement);
        if (modalInstance) {
            modalInstance.hide();
        }

    } catch (error) {
        alert("Error deleting product. Check the console for details.");
    }
}


fetchProducts();